            <div id="footer">
                <span id="border"></span>
                <img src="img/westerdalsLogo.png" alt="Westerdals Oslo ACT" id="footerLogo" />
                <div id="sosialeMedier">
                    <span>Jeg ønsker å holdes oppdatert på <br />hva som skjer. Følg:</span>
                    <ul>
                        <li><a href="https://www.facebook.com/woact" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/westerdalsact" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://instagram.com/westerdalsact/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
                <ul id="footerMenu">
                    <li><a href="tel:22057550">Telefon 22 05 75 50</a></li>
                    <li><a href="mailto:post@westerdals.no">post@westerdals.no</a></li>
                    <li><a href="http://www.westerdals.no/kontakt/">Kontakt</a></li>
                    <li><a href="http://www.westerdals.no/om-oss/">Om oss</a></li>
                    <li><a href="http://www.westerdals.no/informasjonskapsler-cookies/">Informasjonskapsler (cookies)</a></li>
                </ul>
                <span id="lagetAv">Laget av gruppe 36</span>
            </div>
        </div>
    </body>
</html>