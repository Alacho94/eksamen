            <div id="footer">
                Laget av gruppe 36
            </div>
        </div>
    </body>
</html>